/*
 * Copyright (c) 2017 by Artur Andrzejak <arturberlin@gmail.com>
 */


package data

import core.Fragment
import org.junit.Test

class DataManagerTest {
    def path_frags_pandas = "C:\\Artur\\Academic\\Scheduling\\CodeSurfer\\CS-core\\FragmentRepo\\fragments-pandas-v02.yml"


    @Test
    void "Read list of yaml records from file" () {
        def dataManager = new DataManager()
        def data = dataManager.loadYamlAsList(path_frags_pandas)
        // data.each {println it}
        def datalist = data.asList()
        assert datalist.size() > 0
    }

    @Test void "Parse yaml records and move to dictionaries" () {
        DataManager dataManager = DataManager.initializeDataManager(path_frags_pandas)

        assert dataManager.fragmentsById.size() > 0
        assert dataManager.parametersByName.size() > 0
        assert dataManager.groupsById.size() > 0
    }


    @Test void "Retrieve property via parent delegate" () {
        DataManager dataManager = DataManager.initializeDataManager(path_frags_pandas)

        Fragment inheritingFragment = dataManager.fragmentsById["py.pd.004.b"]
        def direct = inheritingFragment.textkey
        // Property got by delegation should not be null
        def delegated = inheritingFragment.commentTemplate
        assert delegated == "rename columns in the dataframe §dataframe§"

        println "\nIn Test: Retrieve property via parent delegate"
        println "Direct property textkey: ${direct}"
        println "Delegated property commentTemplate: ${delegated}"

    }

    @Test void "Retrieve parameters from code" () {
        DataManager dataManager = DataManager.initializeDataManager(path_frags_pandas)

        assert dataManager.fragmentsById.size() > 0
        assert dataManager.parametersByName.size() > 0
        assert dataManager.groupsById.size() > 0

        println "\nIn Test: Retrieve parameters from code"
        dataManager.fragmentsById.each { key, fragment ->
            println "\n** Fragment: ${fragment.textkey}"
            print "   Code: ${fragment.code}"
            def paramList = fragment.retrieveParameterNames()
            println "Parameter list: " + paramList
        }
        // todo: make a part of data setup
        dataManager.fragmentsById.each { key, fragment ->
            fragment.getParameterReferences(dataManager.parametersByName)
            println "\n** Fragment: ${fragment.textkey}"
            println "usedParameterRefs: " + fragment.usedParameterRefs
        }


    }

}
