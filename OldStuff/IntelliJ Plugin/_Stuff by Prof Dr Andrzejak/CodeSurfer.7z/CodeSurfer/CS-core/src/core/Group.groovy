/*
 */

package core

import groovy.transform.CompileStatic

class Group extends DataBean {
    String recType
    String recID
    String parent


    String groupName
    String domain
    String lang
    List<String> requiredPackages
    List<String> keywords

}
