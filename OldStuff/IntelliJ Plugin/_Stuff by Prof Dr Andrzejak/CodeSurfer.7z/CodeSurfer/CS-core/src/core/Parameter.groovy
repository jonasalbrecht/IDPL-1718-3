/*
 * A template for a parameter (variable or expression) to be substituted in a Fragment
 */

package core

//def enum ParameterType {
//    var, expr, example, subfragment
//}

class Parameter extends DataBean {
    String recType
    String recID
    String parent

    String parameterType
    String group

    String name
    // maybe later: introduce sets of types like [string, list<string>]
    String type
    String example
    List<String> names


    // Populate from a yamlRecord
    def fromYaml(Map yamlRecord, Map<String, DataBean> parametersByKey) {
        setPropertiesFromYaml(yamlRecord)

        // todo: Parent's parameterMap uses "name", so this method might be wrong!
        addParentReference(parametersByKey)

        // dataBeanByID[recID] = this
        parametersByKey[name] = this
    }

}
