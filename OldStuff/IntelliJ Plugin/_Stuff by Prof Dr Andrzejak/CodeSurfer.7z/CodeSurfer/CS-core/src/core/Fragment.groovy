/*
 *
 * Encapsulates data of a single code fragment
 */

package core

import java.util.regex.Matcher

class Fragment extends DataBean{
    // Properties
    String recType
    String recID
    String parent

    String group
    List<String> keywords
    List<String> related
    List<String> textkey
    String code
    List<Parameter> parameters
    String commentTemplate
    List<String> sources
    List<String> documentation

    // Refs to parameters found in the fragment
    List<Parameter> usedParameterRefs
    /*
    Considerations on 3.10.2017:
    ** As observed in liveTemplates/CodeSurferJava.xml, each variable in a live template:
       - is marked by $name$
       - has several parameters:
       -- <variable name="FILENAME" expression="complete()" defaultValue="fileName" alwaysStopAt="true" />

       So we need to do, for each possibly matching fragment:
           10. identify "our" variables in the code piece (search for §name§)
           20. try to match variables with existing ones by context, then use matches as defaultValues
           --(LATER: a *list* of ranked defaultValues, also need re-implementation of IDEA's life template)
           30. Decide on the "expression"-parameter (this can be retrieved from the parameter's data)
           40. Dynamically create a life template

       100. Then present a list of life templates to the user
       -- Later: create own list which show full expansion, and list to docu etc.
    */

    protected List retrieveParameterNames() {
        // match all §names§
        def paramPattern = "§(.*?)§"
        Matcher matcher = (code =~ paramPattern)
        // For some reason, "it" is a list of 2 elements, and 2nd is without "§"
        def paramList = matcher.collect {it[1]}
        // make all uniques
        paramList.toSet().toList()
    }

    def getParameterReferences(Map parametersByKeys) {
        def paramList = retrieveParameterNames()
        usedParameterRefs = paramList.collect { parName ->

            def paramRef = parametersByKeys[parName]
            assert paramRef != null,
                    "Unknown parameter with name $parName specified in fragment with recId = $recID"
        }
    }


}
