/*
 * Base class for pieces of data (like Fragment, Parameter, Group)
 */

package core


class DataBean {

    protected DataBean parentRef

    protected propertyNames = this.getProperties().keySet()

    // Default constructor
    DataBean() {}

    // Populate from a yamlRecord
    def fromYaml(Map yamlRecord, Map<String, DataBean> dataBeanByID) {
        setPropertiesFromYaml(yamlRecord)
        addParentReference(dataBeanByID)

        dataBeanByID[recID] = this
    }


    protected void setPropertiesFromYaml(Map yamlRecord) {
        def myClass = this.getClass()
        for (key in yamlRecord.keySet()) {
            assert key in propertyNames,
                    "Yaml data contains invalid property name '$key' for class ${myClass} \nRecord: $yamlRecord"
            def value = yamlRecord[key]
            // getDeclaredField() does not retrieve fields in superclasses, so we have no fields in DataBean
            // also this.class.declaredFields does not retrieve these
            value = wrapInCollectionIfNeeded(value, myClass.getDeclaredField(key).type)
            this.setProperty(key, value)
        }
    }

    protected wrapInCollectionIfNeeded(inData, Class targetFieldClass) {
        if (inData == null)
            return inData
        if (inData.class.equals(targetFieldClass))
            return inData
        if (List.class.equals(targetFieldClass)) {
            return [inData]
        }
        if (Map.class.equals(targetFieldClass))
            assert false, "Wrapping into maps not implemented yet!"
    }


    protected void addParentReference(Map<String, DataBean> dataBeanByID) {
        if (this.parent != null) {
            assert this.parent in dataBeanByID,
                    "No parent named ${this.parent} found for dataBean with recID = ${this.recID}"
            this.parentRef = dataBeanByID[this.parent]
        }
    }



    /**
     * If a property value is null, try to get the value from a parent (only if parentRef != null)
     * @param property
     * @return
     */
    def getProperty(String property) {
        Object result = this.getProperties().get(property);
        if (result != null) {
            return result;
        } else {
            if (this.parentRef != null) {
                try {
                    return parentRef.getProperty(property);
                } catch (MissingPropertyException exception) {
                    return null;
                }
            }
        }
    }



}
