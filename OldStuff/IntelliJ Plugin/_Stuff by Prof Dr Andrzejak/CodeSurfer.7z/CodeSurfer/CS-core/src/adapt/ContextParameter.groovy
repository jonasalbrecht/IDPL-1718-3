/*
 * Bean for holding data of "actual parameters", i.e. context variables
 */

package adapt

import core.Parameter

class ContextParameter extends Parameter{
    // properties
    // Number of lines "above" cursor to last usage
    int numLinesFromCursor
}
