/*
 * Base matcher class for matching (specializing) the formal to actual parameters
 */

package adapt

import com.thoughtworks.qdox.model.util.OrderedMap
import core.Fragment
import core.Parameter

class Suggestion {
    Parameter parameter

    // List of potential matches per formal parameter
    List<ContextParameter> potentialMatches
    // use the following, if we should need a match score for each contextParameter
    //OrderedMap<ContextParameter,  Double> contextParameterToScores
}


class Matcher {
    Matcher(List<ContextParameter> allContextParameters) {
        this.allContextParameters = allContextParameters
    }

    // properties
    List<ContextParameter> allContextParameters
    // set to default matchStrategy
    MatchStrategy matchStrategy  = new MatchStrategyByType()

    Map<Parameter,Suggestion> match(Fragment fragment) {
        assert matchStrategy != null, "matchStrategy not set!"
        return matchStrategy.match(fragment, this)
    }

}

interface MatchStrategy {
    Map<Parameter,Suggestion> match (Fragment fragment, Matcher matcher)
}



class MatchStrategyByType implements MatchStrategy {


    @Override
    Map<Parameter, Suggestion> match(Fragment fragment, Matcher matcher) {
        // todo: implement
        return null
    }
}