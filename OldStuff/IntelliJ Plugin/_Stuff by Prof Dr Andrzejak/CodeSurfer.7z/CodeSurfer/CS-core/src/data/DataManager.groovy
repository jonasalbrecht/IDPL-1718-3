/*
 *
 * Retrieves and holds parameter data,  fragment data, ...
 */

package data

import core.DataBean
import core.Group
import core.Parameter
import core.Fragment
import org.yaml.snakeyaml.Yaml


//@CompileStatic
class DataManager {
    // Constants for yaml records, might be moved somewhere else later
    final static RECTYPE = "recType"
    final static RECID = "recID"

    protected Yaml yamlEngine = new Yaml()

    List loadYamlAsList(String path) {
        InputStream input = new FileInputStream(new File(path));
        def listYamlRecords = yamlEngine.loadAll(input).asList()
        return listYamlRecords
    }



    // Maps [id : record]
    Map<String, Fragment> fragmentsById = new HashMap<String, Fragment>()
    Map<String, Parameter> parametersByName = new HashMap<String, Parameter>()
    Map<String, Group> groupsById = new HashMap<String, Group>()

    // References to methods, see method-pointer-operator (https://goo.gl/sBmCzN)
    protected Map  recTypes2maps= [
            "code_v01":     [fragmentsById, Fragment.class],
            "params_v01":   [parametersByName, Parameter.class],
            "group_v01":    [groupsById, Group.class]
    ]

    /**
     * Instantiates each yaml record and puts it into the right map ...byId
     * @param listYamlRecords
     * @return
     */
    def yamlRecordsToMaps(List listYamlRecords) {
        listYamlRecords.each {Map record ->
            String recType = record[RECTYPE]
            List  map_and_class = recTypes2maps[recType]
            if (map_and_class != null) {
                // DataBean.createFromYaml(record, (Map) map_and_class[0], (Class) map_and_class[1])
                Map<String, DataBean> dataBeanMap = (Map) map_and_class[0]
                Class beanClass = (Class) map_and_class[1]

                // Create instance of aClass and populate with data
                DataBean bean = (DataBean)beanClass.newInstance()
                bean.fromYaml(record, dataBeanMap)
            } else {
                System.err << "Unknown type $recType of a Yaml record found in " + record.toString()
            }

        }
    }

    static DataManager initializeDataManager(path_frags_pandas) {
        def dataManager = new DataManager()
        def data = dataManager.loadYamlAsList(path_frags_pandas)
        // data.each {println it}
        def datalist = data.asList()
        assert datalist.size() > 0

        dataManager.yamlRecordsToMaps(datalist)
        return dataManager
    }

}
