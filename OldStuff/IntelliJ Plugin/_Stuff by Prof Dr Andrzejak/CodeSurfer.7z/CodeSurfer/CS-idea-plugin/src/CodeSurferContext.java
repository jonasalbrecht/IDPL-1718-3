/**
 * Created by Artur on 01.10.2016.
 */

import com.intellij.codeInsight.template.TemplateContextType;
        import com.intellij.psi.PsiFile;
        import org.jetbrains.annotations.NotNull;

public class CodeSurferContext extends TemplateContextType {
    protected CodeSurferContext() {
        super("CODESURFER", "CodeSurferContext");
    }

    @Override
    public boolean isInContext(@NotNull PsiFile file, int offset) {
        return file.getName().endsWith(".java");
    }
}
