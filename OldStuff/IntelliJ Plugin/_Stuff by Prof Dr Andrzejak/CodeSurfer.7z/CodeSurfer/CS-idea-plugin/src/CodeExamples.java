import java.io.*;

/**
 * Created by Artur on 01.10.2016.
 */
public class CodeExamples {

    // Process a file line by line
    public static void main(String[] args) {
        CodeExamples codeExamples = new CodeExamples();

        codeExamples.processFileLinewise("some file name.txt");

    }

    void processFileLinewise(String filename) {

        // Process a file line by line
        File file = new File(filename);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                // do something with line
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
 }
