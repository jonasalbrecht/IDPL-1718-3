import com.intellij.codeInsight.CodeInsightUtilBase;
import com.intellij.codeInsight.template.TemplateManager;
import com.intellij.codeInsight.template.impl.TemplateImpl;
import com.intellij.codeInsight.template.impl.TemplateManagerImpl;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.application.Result;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.ex.util.EditorUtil;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.ui.SelectFromListDialog;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.List;

/**
 * Created by Artur Andrzejak on 03.10.2016.
 * Implements a prototype IDEA plugin which allows to select live templates by matching user's input
 * against template descriptions.
 */

public class BlitzTemplate extends AnAction {

    private MyToStringAspect myToStringAspect = new MyToStringAspect();

    public BlitzTemplate() {
        // Set the menu item name.
        super("Blitz_Template");
        // Set the menu item name, description and icon.
        // super("Blitz_Template","Item description",IconLoader.getIcon("/Mypackage/icon.png"));
    }

    @Override
    public void actionPerformed(AnActionEvent event) {
        Project project = event.getData(PlatformDataKeys.PROJECT);
        Editor editor = event.getData(PlatformDataKeys.EDITOR);
        PsiFile psiFile = event.getData(PlatformDataKeys.PSI_FILE);


        String templateDescription = getUserInputText(project);

        // Prepare list of available templates
        List<TemplateImpl> applicableTemplates = getApplicableTemplates(project, editor, psiFile);
        if (applicableTemplates == null)
            return;

        // todo: filter the applicable templates according to user's input

        // String[] choices = {"A choice", "B choice", "C choice"};
        TemplateImpl selectedTemplate = (TemplateImpl) selectTemplateFromSuggestionsDialog(project, applicableTemplates.toArray());
        System.out.printf("User's response is: " + selectedTemplate.getKey());

        // finally, insert the selected template
        // todo: modify template according to the variables included in user's description
        insertTemplate(project, editor, selectedTemplate);
    }

    @Nullable
    Object selectTemplateFromSuggestionsDialog(Project project, Object[] choices) {
        SelectFromListDialog listDialog = new SelectFromListDialog(project, choices, myToStringAspect, "Select Code Template", ListSelectionModel.SINGLE_SELECTION);
        boolean responseValid = listDialog.showAndGet();
        Object response = null;
        if (responseValid) {
            Object[] selection = listDialog.getSelection();
            response = selection[0];
            // System.out.println("Selected template: " +  response);
        } else {
            // System.out.println("Template selection canceled!");
        }
        return response;

        // An alternative: a *working* but inconvenient selection box
        //String selectedTemplate = Messages.showEditableChooseDialog("Choose Code Fragment", "Select Code Template", Messages.getQuestionIcon(),choices, "default", null);
        //System.out.println("Selected: " +  selectedTemplate);
    }

    private String getUserInputText(Project project) {
        String templateDescription = Messages.showInputDialog(project, "Which code template do you search?", "Input description of desired template", Messages.getQuestionIcon());
        //Messages.showMessageDialog(project, "Hello, you have entered " + codeDescription + "!\n I am glad to confirm this.", "Information", Messages.getInformationIcon());
        return templateDescription;
    }


    private class MyToStringAspect implements SelectFromListDialog.ToStringAspect {
        public String getToStirng(Object obj) {
            if (obj instanceof TemplateImpl)
                return (((TemplateImpl) obj).getDescription());
            else
                return obj.toString();
        }
    }

    /**
     * Returns list of applicable templates in currenct context / at caret position.
     * Copied code fragment from com.intellij.codeInsight.template.impl.ListTemplatesHandler#invoke
     * @param project
     * @param editor
     * @param file
     * @return list of template implementations
     */
    private List<TemplateImpl> getApplicableTemplates(final Project project, final Editor editor, PsiFile file) {
        if (!CodeInsightUtilBase.prepareEditorForWrite(editor)) return null;
        if (!FileDocumentManager.getInstance().requestWriting(editor.getDocument(), project)) {
            return null;
        }
        EditorUtil.fillVirtualSpaceUntilCaret(editor);

        PsiDocumentManager.getInstance(project).commitDocument(editor.getDocument());
        int offset = editor.getCaretModel().getOffset();
        List<TemplateImpl> applicableTemplates = TemplateManagerImpl.listApplicableTemplateWithInsertingDummyIdentifier(editor, file, false);
        return (applicableTemplates);
    }

    /**
     * Inserts a specified live template at current caret.
     * Adapted from com.intellij.codeInsight.template.impl.ListTemplatesHandler.MyLookupAdapter#itemSelected
     * @param project
     * @param editor
     * @param template
     */
    private void insertTemplate (Project project, Editor editor, TemplateImpl template) {
        // final String argument = myTemplate2Argument != null ? myTemplate2Argument.get(template) : null;
        final String argument =  null;
        new WriteCommandAction(project) {
            @Override
            protected void run(@NotNull Result result) throws Throwable {
                ((TemplateManagerImpl) TemplateManager.getInstance(project)).startTemplateWithPrefix(editor, template, null, argument);
            }
        }.execute();
    }
}