#!/usr/bin/env bash
./docker-run.sh 8 -Pwith-java8-tests
