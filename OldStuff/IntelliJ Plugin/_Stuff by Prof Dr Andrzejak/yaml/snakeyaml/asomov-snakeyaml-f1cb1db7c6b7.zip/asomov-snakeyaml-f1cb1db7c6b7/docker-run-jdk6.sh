#!/usr/bin/env bash
./docker-run.sh 6

