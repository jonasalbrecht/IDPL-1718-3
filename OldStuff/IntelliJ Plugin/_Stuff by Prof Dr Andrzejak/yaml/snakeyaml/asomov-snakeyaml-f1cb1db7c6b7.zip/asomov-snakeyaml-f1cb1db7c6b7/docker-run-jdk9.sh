#!/usr/bin/env bash
./docker-run.sh 9

